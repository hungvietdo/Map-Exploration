#define MAX_LEN 100

#include <iostream>
#include <tchar.h>

#include "runningcar.h"
#include <string>
#include <sstream>
#include <time.h>
#include <stdio.h>
#include "Serial.h"

using namespace std;
unsigned int alarm(unsigned int seconds);

Serial* SP = new Serial("\\\\.\\COM3");    // adjust as needed

char sensor_info;
int step_count =0;
int count_to_exit = 0;

char Command_Sensor(char *ch)
{
    clock_t begin, end;
    double time_spent;
    int running_time;

    bool ii = SP->WriteData(ch,1);
    begin = clock();
    int readResult = 1;
    char incomingData[MAX_LEN] = "";

         do {
            memset(incomingData, '\0', MAX_LEN);
            readResult = SP->ReadData(incomingData,10);
           if ((strncmp(incomingData,"1",1)==0) || (strncmp(incomingData,"0",1)==0) )
            {
                 printf("Received sensor info from car:%s\n",incomingData);
                 break;
            }
            end = clock();
            time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
        } while ((time_spent<2) ); //waiting for 2 seconds

   //two seconds for the led off (receiving led)
    printf("time spent:%f\n",time_spent );



    if (strncmp(incomingData,"0",1)==0) return '0';
    if (strncmp(incomingData,"1",1)==0) return '1';

}

void Command_Data (char *ch)
{
    clock_t begin, end;
    double time_spent;
    int running_time;

    bool ii = SP->WriteData(ch,1);
    begin = clock();

    int readResult = 1;
    char incomingData[MAX_LEN] = "";

        do {
            memset(incomingData, '\0', MAX_LEN);
            readResult = SP->ReadData(incomingData,10);
            if (!strncmp(ch,incomingData,1))
            {
                 printf("Received complete message from car:%s\n",incomingData);
                  Sleep(2);
                 break;
            }
            end = clock();
            time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
        } while ((time_spent<10) ); //waiting for 10 seconds


   //two seconds for the led off (receiving led)
    printf("time spent:%f\n",time_spent );

    if (time_spent>=10)
    {
        printf("There was no response from the car after 10 seconds. please re-do the test.\n");
        exit (0);
    }

}


int main(int argc, char**argv)
{
    //init data
    dataInitialize();

    if (SP->IsConnected())
		cout << "We're connected";

    char sendBuf[MAX_LEN];
    int bytes;
	 for (;;) {

      //memset(sendBuf, '\0', MAX_LEN);

       scanf("%1s", &sendBuf);
       if (strlen(sendBuf)>0)
       {
           printf("%c\n",Command_Sensor(sendBuf));

       }
    }

    return 0;
}
