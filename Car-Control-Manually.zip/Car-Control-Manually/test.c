#include <time.h>
#include <stdio.h>

int main()
{
   clock_t begin, end;
double time_spent;

int running_time;
begin = clock();

do {

end = clock();
time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
} while (time_spent<2);

printf("time spent:%f\n",time_spent );

   return(0);
}