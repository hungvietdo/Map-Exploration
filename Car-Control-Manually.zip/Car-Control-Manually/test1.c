#include <stdio.h>

void playgame()
{
    printf( "Play game called" );
}
void loadgame()
{
    printf( "Load game called" );
}
void playmultiplayer()
{
    printf( "Play multiplayer game called" );
}
	
int main()
{
    int input;
	
for(;;)
{
    printf("\n\n");
	printf("===============================================\n");
    printf( "1. Find a path.\n" );
    printf( "2. Use the short-test path to the destination.\n" );
    printf( "3. Learn more about the map.\n" );
    printf( "4. Exit\n" );
    printf("===============================================\n");
    printf( "Get the car ready and make a selection: " );
    scanf( "%d", &input );
    switch ( input ) {
        case 1:            /* Note the colon, not a semicolon */
            playgame();
            break;
        case 2:          
            loadgame();
            break;
        case 3:         
            printf( "Function is not available yet!\n" );
            break;
        case 4:        
            printf( "Thanks for riding!\n" );
            return 0;
        default:            
            printf( "Bad input, quitting!\n" );
            break;
    }
    getchar();
}

}